module.exports = {
    trailingComma: "es5",
    tabWidth: 2,
    semi: true,
    singleQuote: false,
    bracketSpacing: true,
    arrowParens: "always",
    tab: 2,
};
